1. Set NDB_OS in Makefile
2. Add path to libNDB_API.so in LD_LIBRARY_PATH
3. Set NDB_CONNECTSTRING
